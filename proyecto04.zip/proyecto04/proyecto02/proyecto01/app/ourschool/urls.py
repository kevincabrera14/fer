from django.urls import path
from django.contrib.auth import views as auth_views  # Agrega esta línea


from . import views


urlpatterns = [
    path('', views.inicio, name="inicio"),
    path('registro/', views.registrarse, name='registarse'),
    path('iniciar/', views.iniciar, name='iniciar'),
    path('pprincipal/', views.iniciar, name='pprincipal'),
    path('cerrar_session/', views.cerrar_session, name='cerrar_session'),
    path('registrarse/', views.registro, name='registro'),
    path('perfil/', views.perfil, name='perfil'),
    path('usuarios/', views.lista_usuarios, name='lista_usuarios'),
    path('guardar/', views.guardar, name='guardar'),
    path('recuperar_contrasena/', views.recuperar_contrasena, name='recuperar_contrasena'),
    path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(template_name='ourschool/password_reset_done.html'), name='password_reset_done'),  # Aquí importamos auth_views y usamos PasswordResetDoneView
    path('correo/', views.correo, name='correo'),
    path('eliminar_usuario/<str:correo>/', views.eliminar_usuario, name='eliminar_usuario'),
    path('admin_editar_formulario<str:correo>', views.admin_editar_formulario, name='admin_editar_formulario'),

    path('guardar_cambios/<str:correo>/', views.guardar_cambios_usuario, name='guardar_cambios'),
    path('agregar_mensaje/', views.agregar_mensaje, name='agregar_mensaje'),


    path('formulario-mensaje/', views.formulario_mensaje, name='formulario_mensaje'),
    path('inicio-profesor/', views.inicio_profesor, name='inicio_profesor'),
    path('inicio-estudiante/', views.inicio_estudiante, name='inicio_estudiante'),
    path('mensajes-profesor/', views.mensajes_profesor, name='mensajes_profesor'),

    path('eliminar-mensaje/<int:mensaje_id>/', views.eliminar_mensaje, name='eliminar_mensaje'),
    path('formulario-mensajes/', views.formulario_mensajes, name='formulario_mensajes'),
    path('chat/', views.chat, name='Mensajes_chat'),

    path('eliminar_mensajes/', views.eliminar_mensajes, name='eliminar_mensajes'),




]

